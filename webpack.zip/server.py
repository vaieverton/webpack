from flask import Flask, render_template
from flask_cors import CORS
app = Flask(__name__, static_folder='./dist/static', template_folder='./dist')

CORS(app)

@app.route('/to-do')
def to_do():
    return render_template('to-do.html')

@app.route('/convidados')
def convidados():
    return render_template('convidados.html') 

if __name__ == '__main__':
    app.run(port=7777, debug=True)
