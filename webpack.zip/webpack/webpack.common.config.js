const path = require('path');
const HtmlWebPackPlugin = require('html-webpack-plugin');

function html(title, entry, filename) {
  return new HtmlWebPackPlugin({
    title,
    template: './src/index.ejs',
    chunks: [entry],
    filename: `${filename}`, 
    favicon: './src/images/favicon.ico',
  });
}

module.exports = {
  entry: {
    toDo: './src/pages/todo/index.js',      
    guests: './src/pages/Guests.js' 
  },
  output: {
    path: path.resolve(__dirname, '../dist'), 
    filename: 'static/[name]-[fullhash].js', 
    publicPath: '/', 
  },
  resolve: {
    extensions: ['.js', '.jsx'],
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env', '@babel/preset-react'],
          },
        },
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'], 
      },
      {
        test: /\.(png|jpg|gif|ico)$/,
        type: 'asset/resource', 
      },
    ],
  },
  plugins: [
    html('To-Do List', 'toDo', 'to-do.html'), 
    html('Guest List', 'guests', 'convidados.html'), 
  ],
};
