const webpack = require('webpack');
const common = require('./webpack.common.config');
const { merge } = require('webpack-merge');
const path = require('path');
const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin');

var config = merge(common, {
  mode: 'development',
  //   optimization: {
  //     minimize: false,
  //     usedExports: true,
  //     splitChunks: false
  //   },
  watchOptions: {
    ignored: /node_modules/,
    // poll: 1000,
  },
  performance: {
    hints: false
  },
  devtool: false, // false é o mais rápido, para debug rapido: 'eval-source-map'
  devServer: {
    static: {
      directory: path.join(__dirname, '../dist/static'),
    },
    compress: true,
    hot: true,
    liveReload: true,
    port: 8080,
    devMiddleware: {
      writeToDisk: true,
    },
    //cache: { type: 'filesystem' }

  },
});

config.plugins.push(
  new ReactRefreshWebpackPlugin(),
);

module.exports = config;
