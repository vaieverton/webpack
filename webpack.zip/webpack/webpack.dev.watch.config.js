const { merge } = require('webpack-merge');
const common = require('./webpack.common.config.js');

const path = require('path');

module.exports = merge(common, {
  mode: 'development',
  watch: true,
  devtool: 'source-map',
  devServer: {
    writeToDisk: 'true',
    port: 8080,
    contentBase: path.join(__dirname, 'dist'),
  }
});
