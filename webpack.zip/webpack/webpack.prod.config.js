const webpack = require('webpack');
const common = require('./webpack.common.config');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const { merge } = require('webpack-merge');
// const CompressionPlugin = require('compression-webpack-plugin');
const TerserPlugin = require("terser-webpack-plugin");

var config = merge(common, {
    mode: 'production',
    // performance: {
    //   hints: 'warning',
    //   maxEntrypointSize: 250000,
    //   maxAssetSize: 250000,
    // },
    // optimization: {
    //     usedExports: true,
    //     splitChunks: {
    //       chunks: 'all',
    //     },
    //     minimize: true,
    //     minimizer: [
    //       new TerserPlugin({
    //         terserOptions: {
    //           format: {
    //             comments: false,
    //           },
    //         },
    //         extractComments: false,
    //       }),
    //       new CssMinimizerPlugin(), 
    //     ],
    //   },
});

config.plugins.push(
    // new webpack.optimize.AggressiveMergingPlugin(),
    // new CompressionPlugin({
        // algorithm: "gzip",
        // test: /\.js$|\.css$|\.html$/,
        // threshold: 10240,
        // minRatio: 0
    // }),
);

module.exports = config;
