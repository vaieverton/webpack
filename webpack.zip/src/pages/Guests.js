import React from 'react';
import ReactDOM from 'react-dom';

import '../global.css';

import { Container, Typography, List, ListItem, ListItemText } from '@mui/material';

const Guests = () => {
  const guestList = ['Ana', 'Carlos', 'Beatriz', 'João', 'Maria'];

  return (
    <Container maxWidth="sm" style={{ textAlign: 'center', marginTop: '20px' }}>
      <Typography variant="h4" gutterBottom>
        Lista de Convidadosaaaa
      </Typography>
      <List>
        {guestList.map((guest, index) => (
          <ListItem key={index}

          >
            <ListItemText primary={guest} />
          </ListItem>
        ))}
      </List>
    </Container>
  );
};

export default Guests;

ReactDOM.render(<Guests />, document.getElementById('root'));

