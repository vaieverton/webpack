import React, { useState } from 'react';
import { Typography, TextField, Button, List, ListItem, ListItemText, IconButton } from '@mui/material';
import Container from '@mui/material/Container';
import DeleteIcon from '@mui/icons-material/Delete'; // Make sure this is correct
import '../../global.css';

const ToDo = () => {
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState("");

  const addTask = () => {
    if (input.trim() === "") return;
    setTasks([...tasks, input]);
    setInput("");
  };

  const deleteTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  return (
    <Container maxWidth="sm" style={{ textAlign: 'center', marginTop: '20px' }}>
      <Typography variant="h4" gutterBottom>
        To-Do Listaaaa
      </Typography>
      <TextField
        label="Adicionar nova tarefa..."
        variant="outlined"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        fullWidth
        margin="normal"
      />
      <Button variant="contained" color="primary" onClick={addTask} style={{ marginBottom: '20px' }}>
        Add Taskasd
      </Button>
      <List>
        {tasks.map((task, index) => (
          <ListItem
            key={index}
            secondaryAction={
              <IconButton edge="end" aria-label="delete" onClick={() => deleteTask(index)}>
                <DeleteIcon />
              </IconButton>
            }
          >
            <ListItemText primary={task} />
          </ListItem>
        ))}
      </List>
    </Container>
  );
};

export default ToDo;
