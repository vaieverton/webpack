import React from 'react';
import ReactDOM from 'react-dom';

import ToDo from './ToDo';

function Index() {
  return <div>
    <ToDo />
  </div>;
}

ReactDOM.render(<Index />, document.getElementById('root'));
